﻿namespace MoneyMap.Models
{
    public class moneyMapModel
    {
        public int Id { get; set; }
        public int Budget { get; set; }
        public string ExpenseTitle { get; set; }
        public string Amount { get; set; }
    }
}
