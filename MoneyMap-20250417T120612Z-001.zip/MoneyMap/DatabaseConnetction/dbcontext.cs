﻿namespace MoneyMap.DatabaseConnetction
{
    public class dbcontext 
    {
    }
}
